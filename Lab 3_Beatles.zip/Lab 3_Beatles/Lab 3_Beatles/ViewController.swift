//
//  ViewController.swift
//  Lab 3_Beatles
//
//  Created by Will Dow on 9/16/14.
//  Copyright (c) 2014 Will Dow. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    func updateImage(){
        if imageControl.selectedSegmentIndex==0 {
            titleLabel.text="Young Beatles"
            beatlesImage.image=UIImage(named: "beatles1.png")
        }
        else if imageControl.selectedSegmentIndex==1 {
            titleLabel.text="Not so young Beatles"
            beatlesImage.image=UIImage(named: "beatles2.png")
        }
    }
    
    func updateCaps(){
        if capitalizedSwitch.on{
            titleLabel.text=titleLabel.text.uppercaseString
        } else{
            titleLabel.text=titleLabel.text.lowercaseString
        }
    }
  
                            
    @IBAction func changeImage(sender: UISegmentedControl) {
       updateImage()
        updateCaps()
    }
    @IBAction func updateFont(sender: UISwitch) {
        updateCaps()
    }
    @IBAction func fontSlider(sender: UISlider) {
        let fontSlider=sender.value
        fontSizeLabel.text=String(format: "%.0f", fontSlider)
        let fontSliderCGFloat=CGFloat(fontSlider)
        titleLabel.font=UIFont.systemFontOfSize(fontSliderCGFloat)
    }
    @IBOutlet weak var fontSizeLabel: UILabel!
    @IBOutlet weak var capitalizedSwitch: UISwitch!
    @IBOutlet weak var beatlesImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var imageControl: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        imageControl.selectedSegmentIndex = -1
        // Dispose of any resources that can be recreated.
    }


}

